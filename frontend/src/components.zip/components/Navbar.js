// src/components/Navbar.js
import React from 'react';
import { NavLink } from 'react-router-dom';
import '../styles/Navbar.css';

function Navbar() {
    return (
        <nav className="navbar">
            <ul className="navbar-list">
                <li><NavLink to="/dashboard" activeClassName="active">Dashboard</NavLink></li>
                <li><NavLink to="/inventory-tracking" activeClassName="active">Inventory Tracking</NavLink></li>
                <li><NavLink to="/product-info-management" activeClassName="active">Product Info</NavLink></li>
                <li><NavLink to="/order-management" activeClassName="active">Order Management</NavLink></li>
                <li><NavLink to="/stock-movement" activeClassName="active">Stock Movement</NavLink></li>
                <li><NavLink to="/reorder-management" activeClassName="active">Reorder Management</NavLink></li>
                <li><NavLink to="/reporting-analytics" activeClassName="active">Reporting & Analytics</NavLink></li>
                <li><NavLink to="/user-access-control" activeClassName="active">User Access</NavLink></li>
            </ul>
        </nav>
    );
}

export default Navbar;
