// src/App.js
import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout';
import Dashboard from './components/Dashboard';
import InventoryTracking from './components/InventoryTracking';
import ProductInfoManagement from './components/ProductInfoManagement';
import OrderManagement from './components/OrderManagement';
import StockMovement from './components/StockMovement';
import ReorderManagement from './components/ReorderManagement';
import ReportingAndAnalytics from './components/ReportingAndAnalytics';
import UserAccessControl from './components/UserAccessControl';
import Login from './components/Login';
import Register from './components/Register';

function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Login />} />
                <Route path="/register" element={<Register />} />
                <Route path="/" element={<Layout />}>
                    <Route path="/dashboard" element={<Dashboard />} />
                    <Route path="/inventory-tracking" element={<InventoryTracking />} />
                    <Route path="/product-info-management" element={<ProductInfoManagement />} />
                    <Route path="/order-management" element={<OrderManagement />} />
                    <Route path="/stock-movement" element={<StockMovement />} />
                    <Route path="/reorder-management" element={<ReorderManagement />} />
                    <Route path="/reporting-analytics" element={<ReportingAndAnalytics />} />
                    <Route path="/user-access-control" element={<UserAccessControl />} />
                </Route>
            </Routes>
        </Router>
    );
}

export default App;
